"""Small executable research examples."""
